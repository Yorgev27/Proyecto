					<!-- // ESTA VENTANA DE CONFIRMACIÓN SERA UTILIZADA CUANDO EL USUARO DEBA CONFIRMAR UNA RESPUESTA O UNA ACCIÓN  -->
					<div class="fixed-black" style="display: none;">
						<div class="ventana ventanaConfirmacion box box-white boxshadow_strong" style="width: 300px; height: 200px;">
							<span class="icon-x closewindow"></span>
							<!-- <div class="contenido boxpadding">
								<h5 class="textcenter">Confirmar eliminación</h5>
								<p class="textcenter">¿Seguro que deseas eliminar <strong>Estudiantes</strong>?</p>
								<ul class="flex flex-wrap flex-margin">
									<li>
										<button class="btn btn-success">CONFIRMAR</button>
									</li>
									<li>
										<button class="btn btn-danger">CANCELAR</button>
									</li>
								</ul>
							</div> -->

						</div>
					</div>
					<?php include 'components/timeline.php'; ?>
				</div> <?php // end de row ?>
			</div> <?php // END DE CONTENT-FUID ?>
		</div> <?php  // END DE CONTENT-WRAPPER ?>
	</div> <?php // END DE CONTENT-ALL ?>
	<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="js/global.js"></script>
	<script type="text/javascript" src="js/registroAjax.js"></script>
	<script type="text/javascript" src="js/eliminarAjax.js"></script>
	<script type="text/javascript" src="js/Access.js"></script>
</body>
</html>
